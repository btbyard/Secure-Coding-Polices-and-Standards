// NumericOverflows.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>     // std::cout
#include <limits>       // std::numeric_limits

/// <summary>
/// Template function to abstract away the logic of:
///   start + (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to add each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>start + (increment * steps)</returns>
/// 
/// 
/// 
/// 


template <typename T>
T add_numbers(T const& start, T const& increment, unsigned long int const& steps)
{
    T result = start;


    for (unsigned long int i = 0; i < steps; ++i)
    {
        result += increment;

        //max number of each data type
        T maxNum = (std::numeric_limits<T>::max());

        //Test for Overflow 
        //originally had if (result > maxNum - steps)
        if ((increment*steps) > (maxNum)) {
            T overflow = 1;
            return overflow;
        }
        

    }

    return result;
}

/// <summary>
/// Template function to abstract away the logic of:
///   start - (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to subtract each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>start - (increment * steps)</returns>

template <typename T>
T subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps)
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        result -= decrement;

        int minNum = std::numeric_limits<T>::max();

        if ((decrement * steps) > minNum){
            T fail = 1;
            return fail;
        }


    }

    return result;
}


//  NOTE:
//    You will see the unary ('+') operator used in front of the variables in the test_XXX methods.
//    This forces the output to be a number for cases where cout would assume it is a character. 

template <typename T>
void test_overflow()
{
    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we add each step (result should be: start + (increment * steps))
    const T increment = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = 0;

    std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    std::cout << "\tAdding Numbers Without Overflow (" << +start << ", " << +increment << ", " << steps << ") = ";
    T result = add_numbers<T>(start, increment, steps);

    //after result is calulated if it failed say error, otherwise display overflow result
    if (result == 1) {
        std::cout << "OVERFLOW OCCURED" << std::endl;
    }
    else {
        std::cout << +result << std::endl;
    }
    
    //std::cout << +result << std::endl;


    std::cout << "\tAdding Numbers With Overflow (" << +start << ", " << +increment << ", " << (steps + 1) << ") = ";
    result = add_numbers<T>(start, increment, steps + 1);

    //IF Overflow occurs ouput error statement
    if (result == 1) {
        std::cout << "OVERFLOW OCCURED" << std::endl;
    }
    else {
        std::cout << +result << std::endl;
    }
    //std::cout << "\t    OVERFLOW HAS OCCURED HERE\n";
}

template <typename T>
void test_underflow()
{

    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we subtract each step (result should be: start - (increment * steps))
    const T decrement = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = std::numeric_limits<T>::max();

    std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE


    std::cout << "\tSubtracting Numbers Without Overflow (" << +start << ", " << +decrement << ", " << steps << ") = ";
    auto result = subtract_numbers<T>(start, decrement, steps);
    if (result == 1) {
        std::cout << "UNDERFLOW OCCURED" << std::endl;
    }
    else {
        std::cout << +result << std::endl;
    }

    std::cout << std::endl;
    std::cout << "\tSubtracting Numbers With Overflow (" << +start << ", " << +decrement << ", " << (steps + 1) << ") = ";
    result = subtract_numbers<T>(start, decrement, steps + 1);
    
    //after result is calulated if it failed say error, otherwise display underflow result
    if (result == 1) {
        std::cout << "UNDERFLOW OCCURED" << std::endl;
    }
    else {
        std::cout << +result << std::endl;
    }
    
}

void do_overflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Overflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_overflow<char>();
    //Max is 127
    test_overflow<wchar_t>();
    //Max is greater than 65536
    test_overflow<short int>();
    //Max is 32767
    test_overflow<int>();
    //Max is 2147483647
    test_overflow<long>();
    //Max is 2147483647
    test_overflow<long long>();
    //Max is 9,223,372,036,854,775,807

    // unsigned integers
    test_overflow<unsigned char>();
    //0  to 255
    test_overflow<unsigned short int>();
    //0 to 65535
    test_overflow<unsigned int>();
    //0 to 4294967295
    test_overflow<unsigned long>();
    //0 to 4294967295
    test_overflow<unsigned long long>();
    //0 to 18446744073709551615

    // real numbers
    test_overflow<float>();
    //1.17549e-038 to 3.40282e+038
    test_overflow<double>();
    //2.22507e-308 to 1.79769e+308
    test_overflow<long double>();
    //3.3621e-4932 to 1.18973e+4932
}

void do_underflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Undeflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_underflow<char>();
    //min -128
    test_underflow<wchar_t>();
    //min - 2^16
    test_underflow<short int>();
    //min -32768
    test_underflow<int>();
    //min -21474883648
    test_underflow<long>();
    //min -21474883648
    test_underflow<long long>();
    //min -18446744073709551615

    // unsigned integers
    // Anything under zero is underflow
    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();

    // real numbers
    test_underflow<float>();
    //1.17549e-038
    test_underflow<double>();
    //2.22507e-308
    test_underflow<long double>();
    //3.3621e-4932
}

/// <summary>
/// Entry point into the application
/// </summary>
/// <returns>0 when complete</returns>
int main()
{
    //  create a string of "*" to use in the console
    const std::string star_line = std::string(50, '*');

    std::cout << "Starting Numeric Underflow / Overflow Tests!" << std::endl;

    // run the overflow tests
    do_overflow_tests(star_line);

    // run the underflow tests
    do_underflow_tests(star_line);

    std::cout << std::endl << "All Numeric Underflow / Overflow Tests Complete!" << std::endl;

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu